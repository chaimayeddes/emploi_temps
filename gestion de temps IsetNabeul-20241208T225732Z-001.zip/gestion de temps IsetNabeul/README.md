# _PI GESTION DES EMPLOIS DU TEMPS_

Une application de gestion d’emploi du temps.
Cette platforme a comme finalité de remplacer la gestion manuelle des plannings au sein de l'ENSET Mohammedia

## Démonstration
Clickez sur l'umage pour voir la démonstration 

[![](Rapport/Pr%C3%A9sentation%20PI.png)
](https://www.youtube.com/watch?v=Yxd4z5WS6Fw)

## Rapport de projet et présentation powerpoint

Le rapport de projet et la présentation powerpoint sont disponibles dans le dossier Rapport.
